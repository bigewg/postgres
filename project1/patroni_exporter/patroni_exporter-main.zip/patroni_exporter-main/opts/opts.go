package opts

type PatroniOpts struct {
	Host string
	Port string
}
